#!/bin/bash

gcc exploit-1.c -o exploit-1
gcc exploit-2.c -o exploit-2
